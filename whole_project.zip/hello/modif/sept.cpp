/*
 * sept.cpp
 *
 *  Created on: Sep 9, 2019
 *      Author: OS1
 */

#include "thread.h"
#include "event.h"
#include "semaphor.h"
#include "intLock.h"
#include <stdlib.h>     /* srand, rand */
/*
 * @brief Modification test - signals are sent with parameter timeout.
 * @detail Signal is blocked until given time elapses. Thread B sends 10 signals
 * with ids (5,6,7,8) with random timeout. After that it's blocked until some key
 * is pressed again. When end is pressed, thread B is unblocked and sends another
 * 10 signals and so on.
 * Thread A receives these signals.
 */

int END = 0;			//!< Finish program when someone presses esc.
extern int globalTimeout;

void signalHandler5(){
	intLock
	cout << "signal handler 5, timeout was " << globalTimeout << endl;
	intUnlock
}

void signalHandler6(){
	intLock
	cout << "signal handler 6, timeout was " << globalTimeout << endl;
	intUnlock
}

void signalHandler7(){
	intLock
	cout << "signal handler 7, timeout was " << globalTimeout << endl;
	intUnlock
}

void signalHandler8(){
	intLock
	cout << "signal handler 8, timeout was " << globalTimeout << endl;
	intUnlock
}

class A : public Thread {
public:
	A(): Thread(defaultStackSize, 1) {}
	virtual ~A() { waitToComplete(); }
protected:
	virtual void run(){
		while (!END);
	}
};

A* threadA;

/*
 * @brief Thread B
 */
class B :public Thread{
public:
	B():Thread(defaultStackSize, 1){}
	virtual ~B () {waitToComplete();}
	void sendSignals(){
		for(int i = 0; i < 10; i++){
			for(int j = 5; j < 9; j++){
				int timeout = (rand() % 10 + 1)*2;
				intLock
				cout << "Thread B sending signal " << j << " with timeout = " << timeout << endl;
				intUnlock
				threadA->signal(j, timeout);
			}
		}
	}

protected:
	virtual void run();
};

void B::run(){
		intLock
		Event event9(9);
		cout<<"KeyebordListener started!"<<endl;
		intUnlock

		char scancode, status, znak;

		while (!END) {

				event9.wait();
				do{
					status = inportb(0x64); // ocitava statusni reg. sa 64h


					if (status & 0x01){           // Can I read?
						scancode = inportb(0x60);

						if (scancode==-127){
							END = 1;			//!< Finished
						}else {
							if (scancode&0x80) {
								sendSignals();
							}
						}

					};
		       //////////////////////
					asm{
						cli
						in      al, 61h         //; Send acknowledgment without
						or      al, 10000000b   //;   modifying the other bits.
						out     61h, al         //;
						and     al, 01111111b   //;
						out     61h, al         //;
						mov     al, 20h         //; Send End-of-Interrupt signal
						out     20h, al         //;
						sti
					}

				 }while (!END && status & 0x01); //dok se ocitava takav status da je pritisnut neki taster

			}// while

			intLock
			cout<<endl<<"KeyebordListener stopped!"<<endl;
			intUnlock
}

void userMainTest(){

	srand (time(NULL));

	threadA = new A();
	B* threadB = new B();

	threadA->registerHandler(5, signalHandler5);
	threadA->registerHandler(6, signalHandler6);
	threadA->registerHandler(7, signalHandler7);
	threadA->registerHandler(8, signalHandler8);

	threadA->start();
	threadB->start();

	delete threadB;
	delete threadA;

}



