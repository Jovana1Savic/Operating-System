/*
 * @file semaphor.cpp
 * @brief Semaphore definition.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "semaphor.h"
#include "KrnSem.h"

/*
 * @brief Create semaphore.
 */
Semaphore::Semaphore(int init){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	myImpl = new KernelSem(init);
	INTE()
#endif
}

/*
 * @brief Release semaphore and unblock any blocked threads.
 */
Semaphore::~Semaphore(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	delete myImpl;
	INTE()
#endif
}

/*
 * @brief Wait with maxTimeToWait. If given zero argument wait for unlimited time.
 * If thread was unblocked because time to wait has elapsed it will return 0. If it didn't
 * block or was unblocked by signal it will return 1.
 */
int Semaphore::wait(Time maxTimeToWait){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	int ret = myImpl->wait(maxTimeToWait);
	INTE()
#endif
	return ret;
}

/*
 * @brief When given zero argument acts as usual signal operation. When given non
 * negative integer as argument unblocks that many or all (if there's not enough blocked)
 * threads. The remaining tokens are added to value of semaphore.
 * Returns the actual number of unblocked threads.
 */
int Semaphore::signal(int n){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	int ret = myImpl->signal(n);
	INTE()
#endif
	return ret;
}

/*
 * @brief Returns current value of semaphore.
 */
int Semaphore::val() const{
	return myImpl->value();
}
