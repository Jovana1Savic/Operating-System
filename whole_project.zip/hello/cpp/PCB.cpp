/* @file pcb.cpp
 * @brief
 * @detail
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June, 2019
 * @version 1.0.
 */

#include "PCB.h"
#include "Queue.h"
#include "thread.h"

 PCB* PCB::running = 0;		//!< Current active process.
 PCB* PCB::idle = 0;		//!< Idle pcb.
 PCB* PCB::mainPCB = 0;		//!< Main pcb.

unsigned long PCB::counter = 0;

/*
 * @brief Creates process control block for given thread thr, with time slice
 * equal to second argument and stack size, given as first argument (in bytes!).
 * Stack is actually allocated upon starting pcb.
 * @detail Critical section - nested inside other critical sections that are already protected!
 */
PCB::PCB(StackSize stackSz, Time timeSlc, Thread* thr){
	status = New;
	sp = 0, ss = 0, bp = 0;
	//!< Stack is allocated upon start!
	stack = 0;
	myThread = thr;

	//!< Given arg is in bytes, myStackSize is in words.
	if (stackSz > maxStackSize)
		myStackSize = maxStackSize/2;
	else
		myStackSize = stackSz/2;

	timeSlice = timeSlc;
	myQueue = new Queue();
	myID = ++counter;
	timeout = 0;
	if (myID == 1){
		PCB::mainPCB = this;
	}
}

/*
 * @brief Destructor - frees memory.
 * @detail It is used when thread is terminated so queue should be empty.
 */
PCB::~PCB(){
	if (stack) delete stack;
	if (myQueue) delete myQueue;
}

/*
 * @brief Creates stack with initial context.
 * @detail When an interrupt happens 8086 will put PSW, CS, IP,
 * respectively, on stack. Additionally, defining a method as interrupt
 * will create assembly code which pushes ax, bx, cx, dx, es, ds, si, di,
 * bp registers, respectively. Then it moves sp to bp, finally it will
 * allocate two additional spaces and subtract 2 from sp.
 * A return from such method will correspondingly
 * be translated into pop instructions (that will happen after restoring sp's
 * old value from bp).
 * Since context change is done inside an interrupt we need to
 * make sure that PCB's stack is prepared according to this.
 * Note that initial content of these registers (besides IP and CS) isn't important so it's not set.
 *
 * Here's the full content of stack after entering an interrupt. Assuming s denotes
 * value of sp before that (sp points to used location).
 * stack[s-1] = PSW.
 * stack[s-2] = CS
 * stack[s-3] = IP
 * stack[s-4] - stack[s-7] = ax, bx, cx, dx
 * stack[s-8] - stack[s-11] = es, ds, si, di
 * stack[s-12] = bp <- BP, <- SP
 */
void PCB::start(){
	if (status == New){

	stack = new unsigned int[myStackSize];

	if (stack != 0){
#ifndef BCC_BLOCK_IGNORE
		stack[myStackSize-1] = 0x200; 						//!< Set I flag in PSW.
		stack[myStackSize-2] = FP_SEG(&(run_wrapper));		//!< Set wrapper segment address as CS.
		stack[myStackSize-3] = FP_OFF(&(run_wrapper));		//!< Set IP value.

		//!< Set up stack pointer and its segment pointer.
		sp = FP_OFF(stack+myStackSize - 12);
		ss = FP_SEG(stack+myStackSize - 12);
		//!< Set up base pointer.
		bp = FP_OFF(stack+myStackSize - 12);
#endif
		status = Ready;
	}
	//!< Mark as terminated if unable to create stack.
	else
		status = Terminated;
	}
}

/*
 * @brief If stack has been allocated calls thread's function run. After run is finished
 * unblocks any threads that are waiting on this one to complete.
 */
volatile void PCB::run(){

	//! Run thread if stack has been allocated.
	if (myThread && status == Ready){
		myThread->run();
	}

#ifdef SIGNAL
	//!< Send signal 1 to parent thread.
	if (myThread->myParent) (myThread->myParent)->signal(1);
	//!< Send signal 2 to myself.
	myThread->signal(2);
#endif

	//!< Enters critical section. Cleanup after this pcb.
#ifndef BCC_BLOCK_IGNORE
	INTD()

	//!< If there are any PCBs waiting on this one to finish,
	//!< they need to be unblocked and put in Scheduler
	while (myQueue->size() > 0){
		PCB* tmp = myQueue->get(); 	//!< Take blocked one.
		tmp->status = Ready;
		Scheduler::put(tmp); 		//!< Put it in Scheduler.
	}

	status = Terminated;

	//!< Dispatch since we're done here.
	dispatch();

	//! No need to enable interrupts since we won't be back.
#endif
}

/*
 * @brief Since we need static function to create address this wrapper is used to
 * call actual run.
 */
void PCB::run_wrapper(){

	PCB::running->run();
}
