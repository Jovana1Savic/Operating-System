/* @file System.cpp
 * @brief Implementation of functions defined in system.h
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June, 2019
 * @version 1.0.
 */

#include "PCB.h"
#include "SemCol.h"
#include "System.h"
#include "thread.h"
#include "sign.h"
#include "ThrCol.h"

#include <iostream.h>
#include <DOS.H>
#include <STDIO.H>
#include <STDARG.H>

//!< System variables.
volatile unsigned char System::dispatchReq = 0;			//!< No dispatch request.

pInterrupt System::oldTimerInt = 0;						//!< Timer's old interrupt routine.

volatile unsigned int System::counter = 1;				//!< Default time.

Thread* System::initThr = 0;							//!< Initial thread.
Thread* System::idleThr = 0;							//!< Idle thread.

//!< Helper variables during context switch.
static volatile unsigned int tsp; 						//!< Temporary stack pointer.
static volatile unsigned int tss; 						//!< Temporary stack segment pointer.
static volatile unsigned int tbp;						//!< Temporary base pointer.

extern void tick();

int locked = 0;											//!< System locked?
int lockCount = 0;										//!< Number of active locks. Only last unlock will actally unlock system.
/*
 * @brief Locks context switch without disabling interrupts.
 */
void lock(){
#ifndef BCC_BLOCK_IGNORE
INTD()
	locked = 1;
	lockCount++;
INTE()
#endif
}

/*
 * @brief Unlocks context switch.
 */
void unlock(){
	if (--lockCount == 0){
		locked = 0;
		if (System::dispatchReq)
			System::dispatch();
	}
}

/*
 * @brief Initializes system.
 * @detail Replaces old timer interrupt routine with the one that will
 * perform context change. Creates idle and initial threads. Initial thread has id 1,
 * and idle has id 2.
 */
void System::init(){
#ifndef BCC_BLOCK_IGNORE
	INTD()

	//!< Replace old timer interrupt routine with new one.
	oldTimerInt = getvect(Timer_IVT);
	setvect(Timer_IVT, timer);

	//!< Create initial (main) thread. This is currently running thread.
	Thread* initThr = new Thread(8192, 2);
	PCB::running = initThr->myPCB;
	PCB::running->status = Running;

	//!< Create idle thread.
	idleThr = new Idle();
	PCB::idle = idleThr->myPCB;
	idleThr->start();

	INTE()
#endif
}

/*
 * @brief Restores system to its previous state.
 * @detail Returns previous interrupt routine. If there isn't one
 * assumes that system wasn't initialized and returns.
 */
void System::restore(){

	if (oldTimerInt == 0) return; 		//!< System wasn't initialized.

#ifndef BCC_BLOCK_IGNORE
	INTD()

	//!< Release threads.
	delete idleThr;
	delete initThr;

	//!< Return old interrupt routine.
	setvect(Timer_IVT, oldTimerInt);

	INTE()
#endif

}

/*
 * @brief Replace interrupt routine at given entry number with new interrupt routine.
 * Return old interrupt routine.
 */
pInterrupt System::replaceRoutine(unsigned int entryNum, pInterrupt newRoutine){

	if (newRoutine == 0) return 0; 		//!< Invalid argument.

#ifndef BCC_BLOCK_IGNORE
	INTD()
	pInterrupt old = getvect(entryNum);
	setvect(entryNum, newRoutine);
	INTE()
#endif
	return old;
}


/*
 * @brief Dispatch - calls timer's interrupt routine in which the context will be changed.
 */
void System::dispatch(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	dispatchReq = 1;
	asm int Timer_IVT
	INTE()
#endif
}

/*
 * @brief Timer interrupt. Performs context switch.
 */
void interrupt System::timer(...){

	unsigned int callOld = 0;			//!< Call old timer interrupt flag.

	if (!System::dispatchReq) {			//!< This is regular interrupt after 55ms.

		callOld = 1;

		//!< Decrement counter for running thread.
		if (System::counter > 0) System::counter--;

		//!< Tick semaphores.
		SemaphoreCollection::Instance()->tickSemaphores();

		ThreadCollector::Instance()->tickSignals();

		tick();
	}
	/*
	 * If PCB has had processor for longer than its time slice or dispatch was
	 * requested we need to change the context.
	 */
	if (((System::counter == 0) && (PCB::running->timeSlice != 0)) || System::dispatchReq){
		if (!locked){				//!< If someone locked don't change context.

			System::dispatchReq = 0;

			//!< Save old context.
#ifndef BCC_BLOCK_IGNORE
			asm {
				mov tsp, sp
				mov tss, ss
				mov tbp, bp
			}
#endif

			if (PCB::running){
				PCB::running->sp = tsp;
				PCB::running->ss = tss;
				PCB::running->bp = tbp;
			}

			//!< Don't put blocked, terminated or idle threads in scheduler.
			if (PCB::running->status != ForceTerminated && PCB::running->status != Blocked
					&& PCB::running->status != Terminated && PCB::running != PCB::idle)
				Scheduler::put((PCB*)PCB::running);
#ifdef SIGNAL
			//!< If running thread has been killed call idle to clean up.
			if (PCB::running->status == ForceTerminated){
				PCB::running = PCB::idle;
			}
			else
#endif
			//!< Get next thread.
			PCB::running = Scheduler::get();

			//!< If scheduler is empty use idle thread.
			if (PCB::running == 0){
				PCB::running = PCB::idle;
			}

			//!< Set up new context.
			tsp = PCB::running->sp;
			tss = PCB::running->ss;
			tbp = PCB::running->bp;

			System::counter = PCB::running->timeSlice;

#ifndef BCC_BLOCK_IGNORE
			asm {
				mov sp, tsp
				mov ss, tss
				mov bp, tbp
			}
#endif
#ifdef SIGNAL
			//!< Running thread should handle signals if there are any.
			(PCB::running->myThread)->handleSignals();
#endif
		}
		//!< In case we got here because PCB has used up its time, but we were locked.
		else {
			System::dispatchReq = 1;

		}
	}

	//!< Call old interrupt if needed.
	if (callOld)
		System::oldTimerInt();


}










