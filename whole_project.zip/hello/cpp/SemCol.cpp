/*
 * @file semlist.cpp
 * @brief List of all created semaphores used to keep track of them.
 * @detail KernelSem is adding and removing semaphores, upon creation and
 * call to destructor.
 * Tick semaphores is called to note that some amount of time had passed.
 */
#include "SemCol.h"

SemaphoreCollection* SemaphoreCollection::instance = 0;

/*
 * @brief Returns instance of semaphore collection.
 */
SemaphoreCollection* SemaphoreCollection::Instance(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (instance == 0)
		instance = new SemaphoreCollection();
	INTE()
#endif
	return instance;
}

/*
 * @brief Puts semaphore into collection. Not safe to use outside
 * KernelSem.
 */
void SemaphoreCollection::putSemaphore(KernelSem* s){

	SemCollectionElem* newElem = new SemCollectionElem();
	newElem->next = 0;
	newElem->sem = s;

	//!< List empty.
	if (head == 0){
		head = tail = newElem;
		return;
	}

	//!< List not empty, add as last element.
	tail->next = newElem;
	tail = newElem;
}

/*
 * @brief Removes semaphore from the list. Not safe to use outside
 * KernelSem.
 */
void SemaphoreCollection::removeSemaphore(KernelSem* s){

	SemCollectionElem* cur = head, *prev = 0;

	for(; cur != 0; prev = cur, cur = cur->next){
		//!< Remove cur from the list.
		if (cur->sem == s){

			//!< Take care of previous element.
			if (prev == 0)
				head = cur->next;
			else
				prev->next = cur->next;

			//!< Take care of tail.
			if (cur->next == 0)
				tail = prev;

			//!< Release memory.
			delete cur;

			return;
		}
	}
}

/*
 * @brief Call tick for all semaphores. Safe to use.
 */
void SemaphoreCollection::tickSemaphores(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	for(SemCollectionElem* cur = head; cur != 0; cur = cur->next){
		//!< Call tick for each semaphore.
		cur->sem->tickSemaphore();
	}
	INTE()
#endif
}

/*
 * @brief Deletes linked list.
 */
SemaphoreCollection::~SemaphoreCollection(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	while (head){
		SemCollectionElem* old = head;
		head = head->next;
		delete old;
	}

	tail = 0;
	INTE()
#endif
}
