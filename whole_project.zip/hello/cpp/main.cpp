#include "System.h"

int userMain (int argc, char* argv[]);
void userMainTest();

void main(int argc, char* argv[]){
	System::init();

	userMain(argc, argv);

	//userMainTest();

	System::restore();
}


