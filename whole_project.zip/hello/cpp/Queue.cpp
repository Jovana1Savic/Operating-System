/*
 * @file queue.cpp
 * @brief Implements queue as a linked list.
 */

#include "Queue.h"

/*
 * @brief Creates new Queue. Called inside critical section.
 */
Queue::Queue(){
	head = 0;
	length = 0;
	timedout = 0;
}

/*
 * @brief Deletes Queue. Called inside critical section.
 */
Queue::~Queue(){
	while(head){
		Elem* old = head;
		head = head->next;
		delete old;
	}

	head = 0; length = 0;

}

/*
 * @brief Insert element at the end of list.
 */
void Queue::put(PCB* p, Time maxTimeToWait){

	Elem *prev = 0, *cur = head;
	for (; cur != 0; prev = cur, cur = cur->next){
		if (cur->pcb == p){
			return;		//!< Already in queue, no need to add it.
		}
	}

	Elem* newElem = new Elem();
	newElem->pcb = p;
	newElem->next = 0;
	newElem->timeToWait = maxTimeToWait;
	newElem->timedWait = (maxTimeToWait != 0 );

	if (!head)
		head = newElem;
	else
		prev->next = newElem;

	length++;

}

/*
 * @brief If timeout equals 0 return first element and remove it from queue.
 * If it's not zero take the first element that has timed out.
 */
PCB* Queue::get(int timeout){
	if (!head) return 0;

	Elem* tmp = head;
	//!< When timeout == 0 just act like regular queue and return the first element.
	if (timeout == 0){
		head = head->next;
		length--;
		//!< The element might be first and its block time has passed. In that case
		//!< remove it from the timed out elements.
		if ((tmp->timedWait != 0) && (tmp->timeToWait == 0))
			timedout--;
	}
	//!< Take the first element that has timed out.
	else {
		Elem *prev = 0;
		for (; tmp != 0; prev = tmp, tmp = tmp->next){
			if ((tmp->timedWait != 0) && (tmp->timeToWait == 0)){
				//!< Return this element.
				if (prev != 0)
					prev->next = tmp->next;
				else
					head = tmp->next;

				timedout--;
				length--;
				PCB* ret = tmp->pcb;
				delete tmp;
				return ret;
			}
		}
		return 0;	//!< Return 0 in case nothing timed out.
	}

	PCB* ret = tmp->pcb;
	delete tmp;
	return ret;
}

/*
 * @brief Notes that 55ms had passed.
 */
void Queue::tick(){
	//!< Increase elapsed time for each element with timed wait.
	//!< Do not decrease time if it's already zero since it will overflow!
	for (Elem *cur = head; cur != 0; cur = cur->next){
		if ((cur->timedWait != 0) && (cur->timeToWait != 0)){
			if (--cur->timeToWait == 0)
				timedout++;
		}
	}
}
