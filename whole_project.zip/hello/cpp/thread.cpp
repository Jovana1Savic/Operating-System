/*
 * @file thread.cpp
 * @brief Thread implementation.
 */
#include "thread.h"


#include "sign.h"
#include "PCB.h"
#include "Queue.h"
#include "ThrCol.h"

/*
 * @brief Creates thread and if created successfully puts it in ThreadCollector.
 */
Thread::Thread(StackSize stackSize, Time timeSlice){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	myPCB = new PCB(stackSize,timeSlice, this);
	if (myPCB) ThreadCollector::Instance()->putThread(this);

#ifdef SIGNAL
	//!< If this isn't main PCB set running as its parent.
	if (myPCB != PCB::mainPCB)
		myParent = PCB::running->myThread;
	else
		myParent = 0;

	mySignalQueue = new SignalQueue(this);
	mySignalHandlers = new SignalHandlers(this);
#endif
	INTE()
#endif
}

/*
 * @brief Starts thread by creating and preparing its stack. Puts it in scheduler if it's
 * not Idle thread. Calls dispatch.
 */
void Thread::start(){
#ifndef BCC_BLOCK_IGNORE
	INTD()

	//!< Start and put in scheduler.
	if (myPCB){
		myPCB->start();

		if (myPCB != PCB::idle){
			Scheduler::put(myPCB);
		}
	}

	//!< Switch context.
	dispatch();

	INTE()
#endif
}

/*
 * @brief Blocks running thread until the one for which the function is
 * called is completed.
 */
void Thread::waitToComplete(){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	//!< Don't wait on me if I'm terminated, idle or running.
		if (myPCB->status != Terminated && myPCB != PCB::idle &&
				myPCB != PCB::running && myPCB->status != ForceTerminated){

			PCB::running->status = Blocked;
			myPCB->myQueue->put((PCB*)PCB::running);	//!< Set running as blocked.
			dispatch();									//!< Move on to the next one.
		}
	INTE()
#endif
}

/*
 * @brief Wait on me if I'm not completed. When I'm done remove me from scheduler
 * and release my memory.
 */
Thread::~Thread(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	//!< If pcb was deleted in idle it will be zero.
	if (myPCB){
		waitToComplete();
		ThreadCollector::Instance()->removeThread(this->getId());
#ifdef SIGNAL
		delete mySignalHandlers;
		delete mySignalQueue;
		delete myPCB;
		myParent = 0;
#endif
	}
	INTE()
#endif
}

void dispatch(){
	System::dispatch();
}

/*
 * @brief If I have pcb return its id.
 */
ID Thread::getId(){
	if (myPCB)
		return myPCB->myID;
	return 0;
}

/*
 * @brief Return running thread's id.
 */
ID Thread::getRunningId(){
	return (PCB::running->myID);
}

/*
 * @brief Return thread with given id.
 */
Thread* Thread::getThreadById(ID id){
	return ThreadCollector::Instance()->getThrByID(id);
}

#ifdef SIGNAL

/*
 * @brief Add another signal handler.
 */
void Thread::registerHandler(SignalId signal, SignalHandler handler){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (mySignalHandlers)
		mySignalHandlers->addHandler(signal, handler);
	INTE()
#endif
}


/*
 * @brief Unregisters all handlers for given signal.
 */
void Thread::unregisterAllHandlers(SignalId signal){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (mySignalHandlers)
		mySignalHandlers->removeAllHandlers(signal);
	INTE()
#endif
}

/*
 * @brief Swap two signal handlers to change the order in which they are called.
 */
void Thread::swap(SignalId signal, SignalHandler hand1, SignalHandler hand2){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (mySignalHandlers)
		mySignalHandlers->swapHandlers(signal, hand1, hand2);
	INTE()
#endif

}

/*
 * @brief Block given signal on this thread.
 */
void Thread::blockSignal(SignalId signal){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (mySignalQueue)
		mySignalQueue->blkSignal(signal);
	INTE()
#endif
}

/*
 * @brief Block given signal for all threads.
 */
void Thread::blockSignalGlobally(SignalId signal){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	SignalQueue::blkSignalGlobally(signal);
	INTE()
#endif
}

/*
 * @brief Unblock signal for this thread. Note that there's no effect if the
 * signal is globally blocked.
 */
void Thread::unblockSignal(SignalId signal){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (mySignalQueue)
		mySignalQueue->unblkSignal(signal);
	INTE()
#endif
}

/*
 * @brief Unblock signal for all threads.
 */
void Thread::unblockSignalGlobally(SignalId signal){

#ifndef BCC_BLOCK_IGNORE
	INTD()
	SignalQueue::unblkSignalGlobally(signal);
	INTE();
#endif
}

/*
 * @brief Running thread sends signal to this thread.
 */
void Thread::signal(SignalId signal, int timeout){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (mySignalQueue)
		mySignalQueue->put(signal, timeout);
	dispatch();
	INTE();
#endif
}

/*
 * @brief Handle signals. Note that this function is called inside interrupt. During signal
 * handling interrupts should be enabled but context switch cannot happen.
 */
void Thread::handleSignals(){
	if (mySignalQueue)
		mySignalQueue->handleSignals();
}


#endif
