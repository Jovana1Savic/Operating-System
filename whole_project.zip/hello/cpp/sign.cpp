#include "sign.h"
#include "ThrCol.h"
#include "Queue.h"

#ifdef SIGNAL

int globalTimeout = 0;

unsigned char SignalQueue::globalBlock[NUM_OF_SIGNALS] = {0};

/*
 * @brief Creates empty signal queue. Blocks are inherited from running (parent) thread, with
 * the exception of main thread which has no parent.
 */
SignalQueue::SignalQueue(Thread* myThr) : head(0), tail(0), myThread(myThr){
	//!< Inherit block flags from parent.
	if (myThread->myParent !=0 ){
		SignalQueue* parentQueue = (myThread->myParent)->mySignalQueue;

		for(int i=0; i < NUM_OF_SIGNALS; i++)
			localBlock[i] = parentQueue->localBlock[i];
	}
	//!< No parent, set flags to zero.
	else {
		for(int i=0; i < NUM_OF_SIGNALS; i++)
			localBlock[i] = 0;
	}
}

/*
 * @brief Delete all elements in queue.
 */
SignalQueue::~SignalQueue(){
	while (head){
		SignalQueueElem* old = head;
		head = head->next;
		delete old;
	}
	head = tail = 0;
}

/*
 * @brief Put signal at the end of queue. Note that signals are added as they come, if a signal
 * that's already in queue comes it will be added at the end.
 */
void SignalQueue::put(SignalId signal, int timeout){

	if (signal >= NUM_OF_SIGNALS) return;

	SignalQueueElem* newElem = new SignalQueueElem();
	newElem->next = 0;
	newElem->signal = signal;
	newElem->timeout = timeout;
	newElem->timeLeft = timeout;

	if (head == 0){
		head = tail = newElem;
	}
	else {
		tail->next = newElem;
		tail = newElem;
	}
}

/*
 * @brief Return first available element.
 */
int SignalQueue::get(SignalId* signal, int* timeout){
	for (SignalQueueElem *prev = 0, *cur = head; cur != 0; ){
		// Don't do anything if they are blocked, or need to wait longer.
		if (globalBlock[cur->signal] || localBlock[cur->signal] || (cur->timeout != 0 && cur->timeLeft >0)){
			prev = cur, cur = cur->next;
			continue;
		}
		//!< This is the one. Remove it from queue.
		SignalQueueElem* tmp = cur;
		if (prev)
			prev->next = cur->next;
		else
			head = cur->next;

		if (cur->next == 0)
			tail = prev;

		//!< Copy contents to return value.
		*signal = tmp->signal;
		*timeout = tmp->timeout;

		delete tmp;
		return 1;
	}

	//!< Nothing worked, return 0.
	*signal = 0;
	*timeout = 0;
	return 0;
}

/*
 * @brief Call all handlers from a list for each signal that has arrived unless that
 * signal is blocked.
 */
void SignalQueue::handleSignals(){

	SignalId signal; int timeout;
	while (get(&signal, &timeout)){
		globalTimeout = timeout;
		// Handle signal, but allow interrupts during that time.
		SignalHandlerListElem* hand = (myThread->mySignalHandlers)->handlerHeads[signal];
		for (; hand != 0; hand = hand->next){
			lock();
#ifndef BCC_BLOCK_IGNORE
			asm { sti}			//!< This is called inside interrupt, so interrupts have to be enabled.
			hand->handler();
			asm {cli}
#endif
			unlock();
		}
	}
}

/*
 * @brief Block signal on this queue.
 */
void SignalQueue::blkSignal(SignalId signal){

	if (signal >= NUM_OF_SIGNALS) return;

#ifndef BCC_BLOCK_IGNORE
	INTD()
	localBlock[signal] = 1;
	INTE()
#endif
}

/*
 * @brief Block given signal for all threads.
 */
void SignalQueue::blkSignalGlobally(SignalId signal){

	if (signal >= NUM_OF_SIGNALS) return;

#ifndef BCC_BLOCK_IGNORE
	INTD()
	globalBlock[signal] = 1;
	INTE()
#endif
}

/*
 * @brief Unblock signal for this thread. Note that there's no effect if the
 * signal is globally blocked.
 */
void SignalQueue::unblkSignal(SignalId signal){

	if (signal >= NUM_OF_SIGNALS) return;

#ifndef BCC_BLOCK_IGNORE
	INTD()
	localBlock[signal] = 0;
	INTE()
#endif
}

/*
 * @brief Unblock signal for all threads.
 */
void SignalQueue::unblkSignalGlobally(SignalId signal){

	if (signal >= NUM_OF_SIGNALS) return;

#ifndef BCC_BLOCK_IGNORE
	INTD()
	globalBlock[signal] = 0;
	INTE();
#endif
}

void SignalQueue::tickQueue(){
	for (SignalQueueElem* cur = head; cur != 0; cur = cur->next){
		if (cur->timeout) cur->timeLeft--;
	}
}
/*
 * *************************************************************************
 */

/*
 * @brief Create signal handlers for given thread. Inherit handlers from running thread,
 * or if it's main thread just add signal 0 handler.
 */
SignalHandlers::SignalHandlers(Thread* myThr) :myThread(myThr){

	//!< Set all to zero so that addHandler function doesn't get confused.
	for (int i = 0; i < NUM_OF_SIGNALS; i++)
		handlerHeads[i] = 0;

	//!< If thread has no parent just set signal 0 handler.
	if (myThread->myParent == 0){
		addHandler(0, exitThread);
	}
	//!< Copy parent's handlers.
	else {
		SignalHandlers* myParentsHandlers = (myThread->myParent)->mySignalHandlers;
		for(int i = 0; i < NUM_OF_SIGNALS; i++){
			SignalHandlerListElem* cur = myParentsHandlers->handlerHeads[i];
			//!< Copy each handler.
			for(; cur != 0; cur = cur->next){
				addHandler(i, cur->handler);
			}
		}
	}
}

/*
 * @delete Remove all handlers for each signal.
 */
SignalHandlers::~SignalHandlers(){
	for (int i = 0; i < NUM_OF_SIGNALS; i++)
		removeAllHandlers(i);
	for (i = 0; i < NUM_OF_SIGNALS; i++)
		handlerHeads[i] = 0;
	myThread = 0;
}

/*
 * @brief Add new handler for given signal as last one.
 */
void SignalHandlers::addHandler(SignalId signal, SignalHandler handler){

	if (signal >= NUM_OF_SIGNALS) return;

	SignalHandlerListElem* cur = handlerHeads[signal];
	SignalHandlerListElem* prev = 0;

	//!< Don't add if it's already in the list.
	for(; cur != 0; prev = cur, cur = cur->next){
		if (cur->handler == handler){
				return;
			}
		}

	//!< Prev now points to the last element. Append there.
	SignalHandlerListElem* newElem = new SignalHandlerListElem();
	newElem->next = 0;
	newElem->handler = handler;

	if (prev == 0)
		handlerHeads[signal] = newElem;
	else
		prev->next = newElem;
}

/*
 * @brief Remove all handlers for given signal.
 */
void SignalHandlers::removeAllHandlers(SignalId signal){

	while(handlerHeads[signal]){
		SignalHandlerListElem* old = handlerHeads[signal];
		handlerHeads[signal] = handlerHeads[signal]->next;
		delete old;
	}

	handlerHeads[signal] = 0;
}

/*
 * @brief If there are given handlers in list swap them so that the order in which they are called
 * is changed.
 */
void SignalHandlers::swapHandlers(SignalId signal, SignalHandler hand1, SignalHandler hand2){

	if (signal >= NUM_OF_SIGNALS) return;
	if (hand1 == hand2) return;

	SignalHandlerListElem *first = 0, *prevFirst = 0, *second = 0, *prevSecond = 0, *prev = 0;
	for(SignalHandlerListElem* cur = handlerHeads[signal]; cur != 0; prev = cur, cur = cur->next){
		if (cur->handler == hand1){
				prevFirst = prev;
				first = cur;
		}
		if (cur->handler == hand2){
				prevSecond = prev;
				second = cur;
		}
	}

	//!< One of them isn't in the list, return.
	if (first == 0 || second == 0){
		return;
	}

	//!< Swap these two list elements.
	if (prevFirst != 0)
		prevFirst->next = second;
	else
		handlerHeads[signal] = second;

	if (prevSecond != 0)
		prevSecond->next = first;
	else
		handlerHeads[signal] = first;

	SignalHandlerListElem* firstNext = first->next;
	first->next = second->next;
	second->next = firstNext;
}

/*
 * @brief Mark thread as terminated. Unblock any threads that are blocked on it.
 * Dispatch. Since it's been marked as forcefully terminated upon context switch idle will
 * be called to clean up after the thread. Do not kill main or idle threads.
 */
void exitThread(){

	if (PCB::running == PCB::mainPCB || PCB::running == PCB::idle)
		return;

#ifndef BCC_BLOCK_IGNORE
		INTD()

		//!< If there are any PCBs waiting on this one to finish,
		//!< they need to be unblocked and put in Scheduler
		while ((PCB::running->myQueue)->size() > 0){
			PCB* tmp = (PCB::running->myQueue)->get(); 	//!< Take blocked one.
			tmp->status = Ready;
			Scheduler::put(tmp); 		//!< Put it in Scheduler.
		}

		(PCB::running)->status = ForceTerminated;

		//!< Signal parent that I'm done.
		(((PCB::running->myThread)->myParent)->mySignalQueue)->put(1);

		//!< Dispatch since we're done here.
		unlock();
		dispatch();
#endif
}

#endif
