/*
 * @file KrnSem.cpp
 * @brief KernelSem class definitions.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include "KrnSem.h"
#include "SemCol.h"

unsigned KernelSem::counter = 0;

/*
 * @brief Creates semaphore with given argument as initial value. If it's negative
 * semaphore is created with default initial value.
 * @detail When val is negative, abs(val) is the number of blocked threads. Since
 * there's nothing blocked when semaphore is created, it can't have negative initial
 * value.
 */
KernelSem::KernelSem(int init){

	id = counter++;

	//!< Set up initial value.
	if (init >= 0)
		val = init;
	else
		val = 1;

	//!< Create queue that will contain blocked threads.
	blocked = new Queue();

	//!< Add semaphore to semaphore collection.
	(SemaphoreCollection::Instance())->putSemaphore(this);
}

KernelSem::~KernelSem(){

	//!< Unblock any blocked threads.
	while (blocked->size()>0){
		PCB* pcb = blocked->get();
		//!< If a thread is unblocked because semaphore is destroyed, it counts as timeout.
		pcb->timeout = 1;
		Scheduler::put(pcb);
	}

	//!< Release memory.
	delete blocked;

	//!< Remove this semaphore from collection.
	(SemaphoreCollection::Instance())->removeSemaphore(this);
}

/*
 * @brief Takes semaphore. Returns 0 if semaphore was unblocked
 * because maxTimeToWait has passed. Otherwise returns 1.
 */
int KernelSem::wait(Time maxTimeToWait){
	//!< Set timeout to 0 - just in case.
	PCB::running->timeout = 0;

	if (--val < 0){
		block(maxTimeToWait);
	}

	//!< When this thread was unblocked its timeout was set. Pass
	//!< along the result.
	if (PCB::running->timeout == 1)
		return 0;
	else
		return 1;
}

/*
 * @brief Blocks running thread. Puts it in queue of blocked threads.
 */
void KernelSem::block(Time maxTimeToWait){

	//!< Set status to Blocked and put it in queue.
	PCB::running->status = Blocked;
	blocked->put(PCB::running, maxTimeToWait);

	//!< Move on to next thread.
	dispatch();
}

/*
 * @brief Unblocks n threads. Returns the actual number of unblocked threads.
 * If the argument is negative, returns argument given. If n is zero acts as
 * typical signal operation.
 */
int KernelSem::signal(int n){

	//!< Invalid argument.
	if ( n < 0 ) return n;

	//!< Number of unblocked threads.
	int unblocked = 0;

	//!< Acts as regular signal operation.
	if (n == 0){
		if (val++ < 0)
			unblocked = deblock();
	}

	//!< Unblock n threads or all if n > val.
	else {

		//!< Unblock as long as there are tokens and threads.
		for(; (unblocked < n) && (val < 0); val++ )
			unblocked += deblock();

		//!< Save the remaining tokens.
		val += (n-unblocked);
	}

	return unblocked;
}

/*
 * @brief Unblocks thread that's first in queue. If timeout is set to one it means
 * that this operation was called because of timeout. In that case a thread which has
 * timed out is blocked.
 */
int KernelSem::deblock(int timeout){

	PCB* pcb = blocked->get(timeout);

	//!< Set status, put in scheduler and set timeout.
	if (pcb){
		pcb->status = Ready;
		Scheduler::put(pcb);
		pcb->timeout = timeout;

		return 1;
	}

	//!< There was nothing blocked. Shouldn't happen.
	return 0;
}

/*
 * @brief Signifies that 55ms had passed. Unblocks any threads that have now timed out.
 */
void KernelSem::tickSemaphore(){

	//!< Tick queue of blocked threads.
	blocked->tick();

	//!< Unblock threads that have timed out.
	while(blocked->timedOut() > 0)
		val += deblock(1);
}

