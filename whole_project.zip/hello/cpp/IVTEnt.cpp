#include "IVTEnt.h"
#include "KrnEv.h"

//!< Table of kernel events, one event per IVT row.
KernelEv* IVTEntry::KernelEvTable[256] = {0};

/*
 * @brief Hold old and new interrupt routines. Macro PREPAREENTRY prevents creating
 * two entries for same IVT row.
 */
IVTEntry::IVTEntry(IVTNo no, pInterrupt NewRoutine){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	myIVTNo = no;
	newInt = NewRoutine;
	oldInt = System::replaceRoutine(no, NewRoutine);
	INTE()
#endif
}

/*
 * @brief Return old interrupt routine.
 */
IVTEntry::~IVTEntry(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	System::replaceRoutine(myIVTNo, oldInt);
	INTE()
#endif
}

/*
 * @brief Call signal for corresponding KernelEv (if one was created).
 */
void IVTEntry::signal(){
	if (KernelEvTable[myIVTNo])
	 KernelEvTable[myIVTNo]->signal();
}

/*
 * @brief Call old interrupt routine.
 */
void IVTEntry::callOld(){
	oldInt();
}

