/*
 * @file Idle.cpp
 * @detail Idle thread definition. Part of kernel.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */
#include "Idle.h"
#include "ThrCol.h"
#include "PCB.h"
#include "sign.h"

/*
 * @brief When thread receives signal 0 it should release its resources (but the user still calls delete).
 * Idle thread is used to clean up and release stack, queue, signal queue and signal handlers.
 */
void Idle::run(){
	while (1){
#ifdef SIGNAL
		CollectionElem* cur = ThreadCollector::head;
		ID killedId = 0;
		for(; cur != 0; cur = cur->next){
			//!< Do not kill main or idle thread.
			if ( ((cur->thr)->myPCB)->status == ForceTerminated && (cur->thr)->getId() > 2){
				killedId = (cur->thr)->getId();
				break;
			}
		}
		if (killedId != 0){
#ifndef BCC_BLOCK_IGNORE
			INTD()
			//!< Remove from collector - we won't be able to get its id after deleting pcb, so it needs
			//!< to be removed before that.
			Thread* toKill = ThreadCollector::Instance()->getThrByID(killedId);
			ThreadCollector::Instance()->removeThread(killedId);

			//!< Release this thread's memory.
			(toKill)->myParent = 0;
			delete (toKill)->mySignalHandlers;
			delete (toKill)->mySignalQueue;
			delete (toKill)->myPCB;

			//!< Pointer is not zero after memory is released!
			(toKill)->myPCB = 0;
			(toKill)->mySignalHandlers = 0;
			(toKill)->mySignalQueue = 0;
			INTE()
#endif
		}
#endif
	}

}

