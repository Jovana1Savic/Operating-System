#include "KrnEv.h"

/*
 * @brief Create Kernel event - put it in table of Kernel events from which
 * IVTEntry will call this event's signal function. Set running thread as event owner.
 */
KernelEv::KernelEv(IVTNo no){
	val = 0;
	IVTEntry::KernelEvTable[no] = this;
	myOwner = PCB::running;
	blocked = 0;
	myNo = no;
}

/*
 * @brief Remove this from table of events.
 */
KernelEv::~KernelEv(){
	//!< Unblock thread if there's one waiting for signal.
	if (blocked) {
		blocked->status = Ready;
		Scheduler::put(blocked);
		blocked = 0;
	}

	IVTEntry::KernelEvTable[myNo] = 0;
}

/*
 * @brief Block running thread if that's my owner.
 */
void KernelEv::wait(){
	if (PCB::running != myOwner) return;

	if (val == 0){
		//!< Block thread.
		PCB::running->status = Blocked;
		blocked = PCB::running;

		//!< Move on to next thread.
		dispatch();
	}
	else
		val = 0;
}

/*
 * @brief Unblock previously blocked thread if there is one.
 */
void KernelEv::signal(){

	if (blocked == 0)
		val = 1;
	//!< Unblock thread.
	else {
		blocked->status = Ready;
		Scheduler::put(blocked);
		blocked = 0;
	}
}
