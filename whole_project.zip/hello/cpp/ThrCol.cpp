/*
 * @file ThrCol.cpp
 * @brief ThreadCollector functions definitions.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#include <iostream.h>
#include "ThrCol.h"
#include "thread.h"
#include "sign.h"

ThreadCollector* ThreadCollector::instance = 0;
CollectionElem* ThreadCollector::head = 0;
CollectionElem* ThreadCollector::tail = 0;

ThreadCollector* ThreadCollector::Instance(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	if (instance == 0)
		instance = new ThreadCollector();
	INTE()
#endif
	return instance;
}

/*
 * @brief Go through linked list and find a thread with given ID. If
 * there is no such thread return 0.
 */
Thread* ThreadCollector::getThrByID(ID id){

	CollectionElem* cur = ThreadCollector::head;
	for(; cur != 0; cur = cur->next){
		if (cur->thr->getId() == id)
			return cur->thr;
		}
	return 0;

}

/*
 * @brief Insert new element into list that will keep thread t.
 */
void ThreadCollector::putThread(Thread* t){
	CollectionElem* newElem = new CollectionElem();
	newElem->next = 0;
	newElem->thr = t;

	//!< List empty.
	if (head == 0){
		head = tail = newElem;
		return;
	}

	//!< List not empty, add as last element.
	tail->next = newElem;
	tail = newElem;
}


/*
 * @brief Removes thread with given ID from list.
 */
void ThreadCollector::removeThread(ID id){
	CollectionElem* cur = head, *prev = 0;

	for(; cur != 0; prev = cur, cur = cur->next){
		//!< Remove cur from the list.
		if (cur->thr->getId() == id){
			//!< Take care of previous element.
			if (prev == 0)
				head = cur->next;
			else
				prev->next = cur->next;

			//!< Take care of tail.
			if (cur->next == 0)
				tail = prev;

			//!< Release memory.
			delete cur;
			return;
		}
	}
}

/*
 * @brief Deletes linked list.
 */
ThreadCollector::~ThreadCollector(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	//!< This list should not have elements when destructor is called.
	while (head){
		CollectionElem* old = head;
		head = head->next;
		delete old;
	}

	head = tail = 0;
	INTE()
#endif
}

void ThreadCollector::tickSignals(){
	for (CollectionElem* cur = head; cur != 0; cur = cur->next){
		((cur->thr)->mySignalQueue)->tickQueue();
	}
}
