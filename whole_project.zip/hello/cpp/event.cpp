#include "event.h"
#include "KrnEv.h"


Event::Event(IVTNo ivtNo){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	myImpl = new KernelEv(ivtNo);
	INTE()
#endif
}

Event::~Event(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	delete myImpl;
	INTE()
#endif
}

void Event::wait(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	myImpl->wait();
	INTE()
#endif
}

void Event::signal(){
#ifndef BCC_BLOCK_IGNORE
	INTD()
	myImpl->signal();
	INTE()
#endif
}
