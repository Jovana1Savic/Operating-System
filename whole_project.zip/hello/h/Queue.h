/*
 * @file queue.h
 * @brief Definitions for class Queue. Part of Kernel.
 * @detail Queue is time sensitive. It can return the first element
 * in the queue or the first element that has timed out.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _queue_h_
#define _queue_h_

#include "PCB.h"
#include "semaphor.h"

//!<  Queue is implemented as a linked list.
struct Elem {
	PCB* pcb;
	Time timeToWait;	//!< How long should this pcb be blocked?
	int timedWait;		//!< Should we unblock it if timeToWait has passed?
	Elem* next;
};

class Queue{
public:
	Queue();								//!< Creates empty queue.
	~Queue();								//!< Deletes elements.

public:
	int size() { return length; }			//!< Num of elements in queue.
	int timedOut() { return timedout; } 	//!< Num of elements that have timed out.

protected:
	void put(PCB* p, Time timeToWait=0); 	//!< Put element.
	PCB* get(int timeout = 0);				//!< Get next element and REMOVE it from queue!
	void tick();							//!< Increase time passed for time sensitive pcbs.

private:
	Elem* head;
	int length;
	int timedout;

	friend class KernelSem;
	friend class PCB;
	friend class Thread;
	friend void exitThread();

};

#endif
