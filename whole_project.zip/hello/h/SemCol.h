/*
 * @file SemCol.h
 * @brief SemaphoreCollection class - Kernel.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _semlist_h_
#define _semlist_h_

#include "KrnSem.h"

/*
 * @brief Linked list used to keep track of all created semaphores.
 */
struct SemCollectionElem {
	KernelSem* sem;
	SemCollectionElem* next;
};

/*
 * @brief Class used to keep track of all created semaphores.
 * @detail When timer interrupt happens semaphores in this list "tick" noting
 * that 55ms have passed. Those threads that have been blocked for maxTimeToWait
 * are unblocked after tick.
 */
class SemaphoreCollection{
public:
	static SemaphoreCollection* Instance();
	void tickSemaphores();						//!< Increase time counter of all semaphores in the list. Deblock threads if necessary.

protected:
	void putSemaphore(KernelSem* s);			//!< Add semaphore to list.
	void removeSemaphore(KernelSem* s);			//!< Remove semaphore from the list.

protected:
	SemaphoreCollection() {head = 0, tail = 0;};
	~SemaphoreCollection();

private:
	static SemaphoreCollection* instance;
	SemCollectionElem *head, *tail;

//!< Disabled member functions.
private:
	SemaphoreCollection(const SemaphoreCollection& );
	SemaphoreCollection& operator=(const SemaphoreCollection& tc);

//!< Semaphores are added to collector upon creation and removed when destroyed.
	friend class KernelSem;
};

#endif
