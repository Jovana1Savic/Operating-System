/*
 * def.cpp
 *
 *  Created on: Aug 25, 2019
 *      Author: OS1
 */

#include "System.h"
#include "thread.h"
#include <DOS.H>
#include <STDIO.H>
#include <STDARG.H>

//int mutex_glb = 1;
//
//void mutex_glb_wait(){
// sloop:asm{
//	mov ax, 0
//	xchg ax, mutex_glb
//}
// if(_AX ==0){
//	dispatch();
//	asm jmp sloop;
// }
//}


#define intLock mutex_glb_wait();
#define intUnlock mutex_glb = 1;


int syncPrintf(const char *format, ...)
{
	int res;
	va_list args;
	lock();
		va_start(args, format);
	res = vprintf(format, args);
	va_end(args);
	unlock();
		return res;
}
