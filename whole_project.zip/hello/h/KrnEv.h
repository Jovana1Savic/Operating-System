/*
 * @file KrnEv.h
 * @brief KernelEv class
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 *
 */

#ifndef _KrnEv_h_
#define _KrnEv_h_

#include "IVTEnt.h"
#include "pcb.h"

class KernelEv{
protected:
	KernelEv(IVTNo no);
	~KernelEv();

	void wait();			//!< Block owner thread and wait for interrupt.
	void signal();			//!< Unblock owner thread.

private:
	int val;
	PCB* myOwner;
	PCB* blocked;
	IVTNo myNo;

	friend class Event;
	friend class IVTEntry;
};

#endif
