/* @file pcb.h
 * @brief Contains system's implementation of threads.
 *
 * @detail Contains definition of PCB class which is used
 *  to implement threads in this kernel.
 *  Note that pointers that are being compared need to be huge
 *  instead of far. Far pointers can point to same memory location
 *  without being equal, which is not the case for huge pointers.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June, 2019
 * @version 1.0.
 */

#ifndef _PCB_H_
#define _PCB_H_

#include "System.h"
#include "thread.h"

//!< PCB's status.
enum pcbStatus {New, Ready, Running, Blocked, Terminated, ForceTerminated};

class Thread;
class Queue;

//!< Max stack size is 64 KB.
const StackSize maxStackSize = ((unsigned long)1) << 16;

/*
 * @brief PCB implements threads inside kernel, making actual thread class just an interface.
 */
class PCB{
protected:
	PCB(StackSize stackSz, Time timeSlice, Thread* thr);	//!< Creates PCB without allocating stack.
	~PCB();													//!< Deletes everything.

	void start();					//!< Actually allocates memory for stack. Prepares stack with run.
	volatile void run();			//!< Run thread.
	static void run_wrapper();		//!< Static method for wrapping run.

	ID getID() { return myID; }		//!< PCB's unique ID.

//private:
public:
	unsigned int sp, ss, bp;		//!< Stack pointer, stack segment pointer, base pointer.

	pcbStatus status;				//!< Status.
	Time timeSlice;					//!< PCB will have timeSlice*55ms time to keep CPU in round robin.

	unsigned int *stack;			//!< Process stack.
	StackSize myStackSize;			//<! Given stack size in words.

	Thread* myThread;				//!< Thread that this PCB represents.
	Queue* myQueue;					//!< Keeps track of PCBs blocked waiting on this one to complete.

	static unsigned long counter;	//!< Counter of all active PCBs. Used to set unique ID.
	ID myID;						//!< PCB's unique id.

	int timeout;					//!< Unblocked because of timeout.

	static PCB* running;			//!< Current active process.
	static PCB* idle;				//!< Idle thread.
	static PCB* mainPCB;			//!< Main pcb - inital thread's pcb.

//!< Friend classes and functions.
	friend class System;
	friend class Thread;
	friend class Idle;
	friend class KernelSem;
	friend class KernelEv;

	friend void exitThread();
};

#endif
