/*
 * @file KrnSem.h
 * @brief KernelSem class declarations
 * @detail Kernel's implementation of semaphore.
 *
 * @date August 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _krnsem_h_
#define _krnsem_h_

#include "semaphor.h"
#include "thread.h"

#include <iostream.h>
#include "Queue.h"

/*
 * @brief Kernel's implementation of semaphore.
 */
class KernelSem{
protected:
	KernelSem(int init = 1);			//!< Initial value has to be non negative.
	~KernelSem();						//!< Unblocks any blocked threads when semaphore is released.

	int wait(Time maxTimeToWait);		//!< Take semaphore.
	int signal(int n = 0);				//!< Signal semaphore.

	int value() { return val; };

protected:
	void block(Time maxTimeToWait);		//!< Blocks running thread.
	int deblock(int timeout=0);			//!< Unblocks first available thread.

	void tickSemaphore();				//!< Called inside timer's interrupt to note that 55ms had passed.

private:
	int val;
	Queue* blocked;
	unsigned int id;
	static unsigned counter;

	friend class SemaphoreCollection;	//!< A collection of semaphores is used to tick all of them at once.
	friend class Semaphore;
};

#endif
