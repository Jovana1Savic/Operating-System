/*
 * @file IVTEntry.h
 */

#ifndef _IVTEntry_h_
#define _IVTEntry_h_

#include "System.h"

typedef unsigned char IVTNo;

class KernelEv;

class IVTEntry{
public:
	IVTEntry(IVTNo no, pInterrupt NewRoutine);		//!< Replace interrupt routine at IVT no with new routine.
	~IVTEntry();									//!< Return old routine.

	void signal();									//!< Call KernelEv's signal operation.
	void callOld();									//!< Call old interrupt routine.

private:
	IVTNo myIVTNo;									//!< My number in IVT.

	pInterrupt oldInt;								//!< Old interrupt routine.
	pInterrupt newInt;								//!< New interrupt routine.

	friend class KernelEv;

	static KernelEv* KernelEvTable[256];
};

/*
 * Macro for preparing IVTEntry when creating KernelEv.
 */
#define PREPAREENTRY(numEntry, old)\
void interrupt inter##numEntry(...); \
IVTEntry newEntry##numEntry(numEntry, inter##numEntry); \
void interrupt inter##numEntry(...) {\
newEntry##numEntry.signal();\
if (old == 1)\
newEntry##numEntry.callOld();\
}

#endif
