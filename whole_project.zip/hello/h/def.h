/* @file def.h
 * @brief Contains type definitions, macros and other basic project definitions.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June, 2019
 * @version 1.0.
 */

#ifndef _DEF_H_
#define _DEF_H_

/*
 * Interrupt disable and interrupt enable macros. Used to abstract
 * and enable safe nesting. INTE enables interrupts if and only if
 * they were actually enabled before calling matching INTD.
 */
#define INTD() { asm{ pushf; cli;} }	//<! Disable interrupts.
#define INTE() { asm{ popf } }			//<! Enable interrupts.

#define Timer_IVT 0x08					//<! Timer's IVT entry number.

#define default_time 20;				//<! Default time for pcb holding CPU.

int syncPrintf(const char *format, ...);

#define SIGNAL

#endif
