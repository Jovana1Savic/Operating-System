/*
 * @file idle.h
 * @brief Idle thread. Does nothing.
 * Used when there are no other threads that can be run.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _idle_h_
#define _idle_h_

#include "thread.h"
#include "def.h"

/*
 * @brief Idle thread - does nothing or cleans up after killed threads.
 * @detail A thread used when there are no other threads available, or there's a
 * clean up to do.
 * It is not in the scheduler.
 */
class Idle : public Thread{
public:
	Idle() : Thread(8192, 1) {}
	virtual void run();
};
#endif
