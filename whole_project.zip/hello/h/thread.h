/*
 * @file thread.h
 * @brief Class Thread.
 * @detail Abstraction used to differentiate threads from their implementation.
 *
 * @date July, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _thread_h_
#define _thread_h_

#include "def.h"



typedef unsigned long StackSize;
const StackSize defaultStackSize = 4096;
typedef unsigned int Time; 					//!< Time, x55ms
const Time defaultTimeSlice = 2; 			//!< Default 110ms
typedef int ID;

class PCB; 				//!< Kernel's implementation of a user's thread.

#ifdef SIGNAL

class SignalQueue;
class SignalHandlers;

typedef void (*SignalHandler)();
typedef unsigned SignalId;

#endif

class Thread{
public:
	void start();
	void waitToComplete();
	virtual ~Thread();

	ID getId();
	static ID getRunningId();
	static Thread* getThreadById(ID id);

#ifdef SIGNAL

	void signal(SignalId signal, int timeout = 0);

	void registerHandler(SignalId signal, SignalHandler handler);
	void unregisterAllHandlers(SignalId id);
	void swap(SignalId id, SignalHandler hand1, SignalHandler hand2);

	void blockSignal(SignalId signal);
	static void blockSignalGlobally(SignalId signal);
	void unblockSignal(SignalId signal);
	static void unblockSignalGlobally(SignalId signal);
#endif

protected:
	friend class PCB;
	friend class System;
	Thread(StackSize stackSize = defaultStackSize, Time timeSlice = defaultTimeSlice);
	virtual void run() {}

private:
	PCB* myPCB;

#ifdef SIGNAL
	SignalQueue* mySignalQueue;
	SignalHandlers* mySignalHandlers;

	Thread* myParent;

protected:
	friend void exitThread();

	friend class SignalHandlers;
	friend class SignalQueue;
	friend class Idle;
	friend class ThreadCollector;

	virtual void handleSignals();

#endif
};

void dispatch();

#endif
