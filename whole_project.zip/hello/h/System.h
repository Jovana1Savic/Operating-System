/* @file System.h
 * @brief Contains functions essential to kernel system.
 *
 * @detail Contains definition of System class which is used
 *  to abstract lowest level operations such as interrupts,
 *  dispatch and setting of interrupt routines.
 *
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 * @date June, 2019
 * @version 1.0.
 */

#ifndef _SYSTEM_H_
#define _SYSTEM_H_

#include <dos.h>

#include <iostream.h>

#include "def.h"
#include "Idle.h"
#include "PCB.h"
#include "schedule.h"

//!< Define intrrupt function.
typedef void interrupt (*pInterrupt)(...);		//!< Interrupt function type definition.

class PCB;

/*
 * @brief System class is used to bring together operations such as system initialization, restoration,
 * and context switch.
 */
class System {
public:
	static void init();							//!< Initializes system.
	static void restore();						//!< Restores system to its previous state.

	static void dispatch();						//!< Changes context.

protected:

//!< Replace one interrupt routine with another one.
	static pInterrupt replaceRoutine(unsigned int entryNum, pInterrupt newRoutine);

private:

	static volatile unsigned char dispatchReq;	//!< Dispatch requested?

	static volatile unsigned int counter;		//!< How many time units are left for running thread?

	static pInterrupt oldTimerInt;				//!< Timer's old interrupt routine.
	static void interrupt timer(...);			//!< Timer's new interrupt routine. Defined here.

	static Thread* initThr;						//!< Initial thread.
	static Thread* idleThr;						//!< Idle thread.

	friend class PCB;
	friend class IVTEntry;
	friend void unlock();
};

//!<The following functions disable context change, but do not prevent interrupts!
void lock();							//!< Locks system - disables any context change.
void unlock();							//!< Unlocks system - enables context change.

#endif
