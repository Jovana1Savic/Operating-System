#include "def.h"

#ifdef SIGNAL

#ifndef _Signal_h_
#define _Signal_h_

#include "Thread.h"
#include "System.h"

#define NUM_OF_SIGNALS 16

/*
 * @brief Signal Handlers as a linked list.
 */
struct SignalHandlerListElem {
	SignalHandler handler;
	SignalHandlerListElem* next;
};

/*
 * @brief Signal Queue as a list of signals.
 */
struct SignalQueueElem {
	SignalId signal;
	SignalQueueElem* next;
	int timeout;
	int timeLeft;
};

class SignalQueue {
protected:
	SignalQueue(Thread* myThread);					//!< Create signal queue for given thread.
	~SignalQueue();									//!< Delete list.

	void put(SignalId signal, int timeout = 0);		//!< Add signal to the end of the list.
	void handleSignals();							//!< Respond to all unblocked signals in queue.
	void tickQueue();								//!< Decrement block time for each time blocked signal.
	int get(SignalId* signal, int* timeout);			//!< Get first available element from queue. Returns 0 if there's nothing (ready).

//!< Block/unblock signal operations. A signal is handled if and only if it's not blocked
//!< locally and globally.
	void blkSignal(SignalId signal);					//!< Block signal on this queue.
	static void blkSignalGlobally(SignalId signal);		//!< Block signal for all queues.
	void unblkSignal(SignalId signal);					//!< Unblock signal for this queue.
	static void unblkSignalGlobally(SignalId signal);	//!< Unblock signal on all queues.

private:
	static unsigned char globalBlock[NUM_OF_SIGNALS];  	//!< Global array of block flags for each signal.
	unsigned char localBlock[NUM_OF_SIGNALS];			//!< Local array of block flags for each signal.

	SignalQueueElem *head, *tail;

	Thread* myThread;

	friend class Thread;
	friend class System;
	friend class Idle;
	friend class ThreadCollector;

	friend void exitThread();
};


class SignalHandlers{
protected:
	SignalHandlers(Thread* myThr);				//!< Create handlers for given thread. Inherit handlers from running thread.
	~SignalHandlers();							//!< Delete all lists.

	void addHandler(SignalId signal, SignalHandler hand);	//!< Add handler to the end of the list.
	void removeAllHandlers(SignalId signal);
	void swapHandlers(SignalId signal, SignalHandler hand1, SignalHandler hand2);	//!< Swap places of handlers in list.
private:
	SignalHandlerListElem* handlerHeads[NUM_OF_SIGNALS];
	Thread* myThread;

	friend class Thread;
	friend class SignalQueue;
	friend class System;
	friend class Idle;

	friend void exitThread();
};

#endif

#endif
