/*
 * @file collect.h
 * @brief ThreadCollector class
 * @detail ThreadCollector is an instance used to keep track of
 * created threads. Part of Kernel.
 *
 * @date August, 2019
 * @author Jovana Savic (jovana.savic9494@gmail.com)
 */

#ifndef _ThrCol_h_
#define _ThrCol_h_

#include "def.h"
#include "thread.h"

/*
 * @brief ThreadCollector is implemented as linked list.
 * @detail Since threads are put into collector upon creation, a binary
 * tree would be skewed and look like a linked list anyway (because their
 * id is set via static counter, and a thread is put into collector upon creation).
 */
struct CollectionElem{
	Thread* thr;
	CollectionElem* next;
};

/*
 * @brief ThreadCollector - Singleton design pattern.
 * @detail A class used to keep track of threads. Part of kernel.
 *
 */
class ThreadCollector{
public:
	static ThreadCollector* Instance();
	static Thread* getThrByID(ID id);
	void tickSignals();

//	void displayElements();

//!< Not safe when interrupts are allowed!
protected:
	static void putThread(Thread* thr);
	static void removeThread(ID id);

protected:
	ThreadCollector() {};
	~ThreadCollector();

private:
	static ThreadCollector* instance;
	static CollectionElem *head, *tail;

//!< Disabled member functions.
	ThreadCollector(const ThreadCollector& );
	ThreadCollector& operator=(const ThreadCollector& tc);

//!< Only Thread class is allowed to put and remove threads.
	friend class Thread;

#ifdef SIGNAL
	friend class Idle;
#endif

};

#endif
