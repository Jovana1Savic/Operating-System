/*
 * @file Q.h
 * @brief Timed queue template
 * @detail Timed queue - regular queue with elements that can time out. It can
 * return first element in queue or the first element that has timed out. Returning
 * an element removes it from the queue.
 * A queue can tick (decrease elapsed time for timed elements).
 * It is possible to define a callback function which will be called for each element
 * in queue. If this function returns 1 the element for which it was called will be removed.
 */

#ifndef _q_h_
#define _q_h_

#include "semaphor.h"

typedef int (*callBackFunction)(QueueElem*);

/*
 * @brief Queue element.
 * @detail Queue is implemented as a doubly linked list.
 */
template<class T>
class QueueElem {
private:
	QueueElem<T>* next;
	QueueElem<T>* prev;
	T data;
	Time timeToWait;
	int timedWait;

friend class TimedQueue;
friend class CallbackWrapper;
};



template<class T>
class TimedQueue {
public:
	TimedQueue<T>(): head(0), tail(0), length(0), timedOut(0) {}
	~TimedQueue();

	void push(T data);							//!< Put element at the end of queue.
	element* get(int timeout);					//!< Get first or first timed out element and remove it.

	int timedout() const;						//!< Num of elements that have timed out.
	int size() const;							//!< Num of elements.

	void tickElements();						//!< Decrement time to wait.
	void callCallback(callBackFunction f);		//!< Call callback for each element, remove element if callback returns 1.

private:
	element *head, *tail;

	int timedOut;
	int length;
};

#endif
